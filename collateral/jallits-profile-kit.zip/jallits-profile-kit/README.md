# JALLITS profile kit

Upload PNG files; SVG files are editable source artwork. All names refer to JALLITS, the business entity.

| Destination | File | Size |
|---|---|---|
| GitHub organization avatar | github-org-avatar.png | 512 × 512 |
| LinkedIn company logo | linkedin-company-logo.png | 300 × 300 |
| LinkedIn company logo, higher resolution | linkedin-company-logo-hires.png | 600 × 600 |
| LinkedIn company cover | linkedin-company-cover.png | 1128 × 191 |
| LinkedIn company cover, higher resolution | linkedin-company-cover-hires.png | 2256 × 382 |
| Alternative light square logo | company-logo-light.png | 600 × 600 |

The square artwork keeps the mark and uppercase name within a circle-safe area. The cover reserves the left area for the overlaid company logo. Review LinkedIn's desktop/mobile crop before saving; layouts may change.

Copy-ready fields and an optional GitHub organization profile README are in profile-copy.md. No profile changes have been published. Set factual company fields such as location, company size, founding year, and industry yourself.

Website SVG logos are included unchanged for reuse. Palette: midnight #06090f, mint #70ffe7, violet #ae92ff, white #edf4ff. Typography: Arial/Helvetica sans serif. The cover uses original vector geometry, not stock imagery.

`github-profile-README.md` is ready to copy into the public `.github/profile/README.md` location.

`optional-generated-background.png` is additional AI-generated artwork in the same visual palette. It is not the upload-ready LinkedIn cover; use the dimensioned cover PNG above.
